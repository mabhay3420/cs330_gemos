#include "wc.h"


extern struct team teams[NUM_TEAMS];
extern int test;
extern int finalTeam1;
extern int finalTeam2;

int processType = HOST;
const char *team_names[] = {
  "India", "Australia", "New Zealand", "Sri Lanka",   // Group A
  "Pakistan", "South Africa", "England", "Bangladesh" // Group B
};


void teamPlay(void)
{

}

void endTeam(int teamID)
{

}

int match(int team1, int team2)
{

	return 0;
}

void spawnTeams(void)
{

	
}

void conductGroupMatches(void)
{

}
